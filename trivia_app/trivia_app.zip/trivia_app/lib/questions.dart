import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class QPage extends StatefulWidget {
  @override
  CreateQuestion createState() => new CreateQuestion();
}

class Question {
  String prompt;
  String answer;
  String false1;
  String false2;
  String false3;

  Question(this.prompt, this.answer, this.false1, this.false2, this.false3);

  Question.fromSnapshot(DataSnapshot snapshot):
        prompt = snapshot.value["prompt"],
        answer = snapshot.value["answer"],
        false1 = snapshot.value["false1"],
        false2 = snapshot.value["false2"],
        false3 = snapshot.value["false3"];


  toJson() {
    return {
      "prompt": prompt,
      "answer": answer,
      "false1": false1,
      "false2": false2,
      "false3": false3,
    };
  }
}

class CreateQuestion extends State<QPage> {
  List<Question> questions = List();
  Question question;
  DatabaseReference dbRef;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    question = Question("", "", "", "", "");
    final FirebaseDatabase database = FirebaseDatabase.instance;
    dbRef = database.reference().child('questions');
    dbRef.onChildAdded.listen(_onEntryAdded);
  }

  _onEntryAdded(Event event) {
    setState(() {
      questions.add(Question.fromSnapshot(event.snapshot));
    });
  }

  void handleSubmit() {
    final FormState form = formKey.currentState;

    if (form.validate()) {
      form.save();
      form.reset();
      dbRef.push().set(question.toJson());
    }
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Create a new question!"),
        backgroundColor: Colors.lightGreenAccent,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Flexible(
            flex: 0,
            child: Center(
              child: Form(
                key: formKey,
                child: Flex(
                  direction: Axis.vertical,
                  children: <Widget>[
                    new Text (
                        'Enter prompt, answer, and 3 false answers'
                    ),
                    ListTile(
                      title: TextFormField(
                        initialValue: "",
                        onSaved: (val) => question.prompt = val,
                        validator: (val) => val == "" ? val : null,
                        decoration: InputDecoration(
                            labelText: 'Enter Prompt'
                        ),
                      ),
                    ),
                    ListTile(
                      title: TextFormField(
                        initialValue: "",
                        onSaved: (val) => question.answer = val,
                        validator: (val) => val == "" ? val : null,
                        decoration: InputDecoration(
                            labelText: 'Enter Correct Answer'
                        ),
                      ),
                    ),
                    ListTile(
                      title: TextFormField(
                        initialValue: "",
                        onSaved: (val) => question.false1 = val,
                        validator: (val) => val == "" ? val : null,
                        decoration: InputDecoration(
                            labelText: 'Enter a False Answer'
                        ),
                      ),
                    ),
                    ListTile(
                      title: TextFormField(
                        initialValue: "",
                        onSaved: (val) => question.false2 = val,
                        validator: (val) => val == "" ? val : null,
                        decoration: InputDecoration(
                            labelText: 'Enter a False Answer'
                        ),
                      ),
                    ),
                    ListTile(
                      title: TextFormField(
                        initialValue: "",
                        onSaved: (val) => question.false3 = val,
                        validator: (val) => val == "" ? val : null,
                        decoration: InputDecoration(
                            labelText: 'Enter a False Answer'
                        ),
                      ),
                    ),
                    RaisedButton(
                      onPressed: () {
                        handleSubmit();
                      },
                      color: Colors.lightBlue,
                      padding: EdgeInsets.all(10.0),
                      child: Column(
                        children: <Widget>[
                          Icon(Icons.report),
                          Text("Submit"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          RaisedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel')
          ),
        ],
      ),
    );
  }
}